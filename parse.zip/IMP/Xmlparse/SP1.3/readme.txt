Copyright (c) 1994, 1995, 1996, 1997, 1998 James Clark

This is version 1.3 of SP, an SGML parser.  This distribution contains
only Win32 binaries and documentation.  The source code is available
for anonymous ftp from ftp.jclark.com in the directory /pub/sp.

When you unpacked this distribution, three directories (bin, doc and
pubtext) should have been created.  If they were not, you should
unpack the distribution again using an option (typically -d) that
tells your unzip program to create directories.

All documentation is in HTML format in the doc directory.  Start with
doc/index.html.

To use any of the programs, simply add the bin directory to your PATH.

See the file COPYING.TXT for copying permission.

Please report any bugs to me.  When reporting bugs, please mention
that you are using Win32 version 1.3 and include a complete
self-contained file that will allow me to reproduce the bug.

James Clark
jjc@jclark.com
